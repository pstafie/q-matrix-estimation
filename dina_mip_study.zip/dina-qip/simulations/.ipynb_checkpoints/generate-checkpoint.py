import numpy as np
import itertools
from pysat.formula import CNF, IDPool
from pysat.card import CardEnc, EncType
from pysat.solvers import Solver

def build_Qprime_sat(Jp: int, K: int, max_L: int,
                     atleast_two_per_col: bool = True,
                     forbid_empty_rows: bool = False,
                     exact_two_per_col: bool = False,
                     enc_type: EncType = EncType.seqcounter) -> tuple[CNF, IDPool, dict]:
    """
    Build CNF for Q' ∈ {0,1}^{Jp × K} with:
      - Row cap:        ∀r,  sum_c x[r,c] ≤ max_L
      - Col lower/eq:   ∀c,  sum_r x[r,c] ≥ 2   (if atleast_two_per_col)
                         or  sum_r x[r,c] = 2   (if exact_two_per_col)
      - Distinct cols:  ∀ c1<c2, ∨_r (x[r,c1] ⊕ x[r,c2])
      - Nonempty rows:  ∀r,  sum_c x[r,c] ≥ 1   (if forbid_empty_rows)

    Returns (cnf, vpool, meta) where:
      meta['var_of'](r,c) -> var id for x_{r,c}
      meta['x_vars']      -> list of all x var ids (positive)
      meta['shape']       -> (Jp, K)
    """
    assert Jp >= 1 and K >= 1 and max_L >= 1
    if exact_two_per_col:
        atleast_two_per_col = False

    vpool = IDPool()
    cnf = CNF()
    var = lambda r, c: vpool.id(('x', r, c))  # entry variable x_{r,c}

    # 1) Row-cap: sum_c x[r,c] ≤ max_L
    for r in range(Jp):
        lits = [var(r, c) for c in range(K)]
        if lits:
            enc = CardEnc.atmost(lits=lits, bound=max_L, vpool=vpool, encoding=enc_type)
            cnf.extend(enc.clauses)

    # 2) Column constraints
    for c in range(K):
        lits = [var(r, c) for r in range(Jp)]
        if exact_two_per_col:
            cnf.extend(CardEnc.atleast(lits=lits, bound=2, vpool=vpool, encoding=enc_type).clauses)
            cnf.extend(CardEnc.atmost(lits=lits, bound=2, vpool=vpool, encoding=enc_type).clauses)
        elif atleast_two_per_col:
            cnf.extend(CardEnc.atleast(lits=lits, bound=2, vpool=vpool, encoding=enc_type).clauses)

    # 3) Optional: forbid empty rows (≥1 per row)
    if forbid_empty_rows:
        for r in range(Jp):
            cnf.append([var(r, c) for c in range(K)])

    # 4) Column distinctness via y ↔ (a ⊕ b)
    def xor_equiv(cnf, v_y, v_a, v_b):
        # y <-> (a XOR b)
        cnf.extend([
            [-v_y,  v_a,  v_b],
            [-v_y, -v_a, -v_b],
            [ v_y,  v_a, -v_b],
            [ v_y, -v_a,  v_b],
        ])

    for c1 in range(K):
        for c2 in range(c1 + 1, K):
            y_lits = []
            for r in range(Jp):
                y = vpool.id(('y', r, c1, c2))
                xor_equiv(cnf, y, var(r, c1), var(r, c2))
                y_lits.append(y)
            cnf.append(y_lits)  # at least one XOR true across rows

    meta = {
        'var_of': var,
        'x_vars': [var(r, c) for r in range(Jp) for c in range(K)],
        'shape': (Jp, K),
    }
    return cnf, vpool, meta


def enumerate_Qprime(Jp: int, K: int, max_L: int,
                     atleast_two_per_col: bool = True,
                     forbid_empty_rows: bool = False,
                     exact_two_per_col: bool = False,
                     solver_name: str = 'g4',
                     enc_type: EncType = EncType.seqcounter,
                     max_solutions: int | None = None):
    """
    Generator: yields every satisfying Q' ∈ {0,1}^{Jp×K} under the constraints.
    Uses all-SAT with model-blocking on x-variables only.
    """
    cnf, vpool, meta = build_Qprime_sat(
        Jp, K, max_L,
        atleast_two_per_col=atleast_two_per_col,
        forbid_empty_rows=forbid_empty_rows,
        exact_two_per_col=exact_two_per_col,
        enc_type=enc_type
    )
    x_vars = meta['x_vars']
    Jp_, K_ = meta['shape']
    assert (Jp_, K_) == (Jp, K)

    with Solver(name=solver_name, bootstrap_with=cnf.clauses) as S:
        found = 0
        while S.solve():
            model = set(S.get_model())  # set of signed ints
            # Build Q' from positive assignments of x-vars
            Qp = np.zeros((Jp, K), dtype=np.uint8)
            var = meta['var_of']
            for r in range(Jp):
                for c in range(K):
                    v = var(r, c)
                    Qp[r, c] = 1 if v in model else 0
            yield Qp

            # Block this exact x-assignment (only over decision vars!)
            # Clause: ∨_v (v if v∉model else ¬v)
            block = [(-v if v in model else v) for v in x_vars]
            S.add_clause(block)

            found += 1
            if max_solutions is not None and found >= max_solutions:
                break


def iter_Q_with_SAT(J: int, K: int, max_L: int,
                    complete: bool = True,
                    atleast_two_per_col: bool = True,
                    forbid_empty_rows: bool = False,
                    exact_two_per_col: bool = False,
                    solver_name: str = 'g4',
                    enc_type: EncType = EncType.seqcounter,
                    max_solutions: int | None = None):
    """
    Generator over full Q matrices.

    Parameters
    ----------
    J, K, max_L : int
    complete : bool
        If True, prepend identity block.
    max_solutions : int or None
        If given, stop after yielding this many Q's.

    Yields
    ------
    np.ndarray of shape (J,K)
    """
    if not complete:
        Jp, Kp = J, K
        if Jp == 0:
            return
        count = 0
        for Qp in enumerate_Qprime(Jp, Kp, max_L,
                                   atleast_two_per_col=atleast_two_per_col,
                                   forbid_empty_rows=forbid_empty_rows,
                                   exact_two_per_col=exact_two_per_col,
                                   solver_name=solver_name,
                                   enc_type=enc_type,
                                   max_solutions=max_solutions):
            yield Qp.astype(np.uint8)
            count += 1
            if max_solutions is not None and count >= max_solutions:
                break
    else:
        if J < K:
            raise ValueError("Need J >= K to place identity on top.")
        Jp, Kp = J - K, K
        if Jp == 0:
            yield np.eye(K, dtype=np.uint8)
            return
        I = np.eye(K, dtype=np.uint8)
        count = 0
        for Qp in enumerate_Qprime(Jp, Kp, max_L,
                                   atleast_two_per_col=atleast_two_per_col,
                                   forbid_empty_rows=forbid_empty_rows,
                                   exact_two_per_col=exact_two_per_col,
                                   solver_name=solver_name,
                                   enc_type=enc_type,
                                   max_solutions=max_solutions):
            yield np.vstack([I, Qp]).astype(np.uint8)
            count += 1
            if max_solutions is not None and count >= max_solutions:
                break


def all_Q_with_SAT(*args, max_solutions: int | None = None, **kwargs) -> list[np.ndarray]:
    """
    Collects up to `max_solutions` Q's into a list.
    """
    return list(iter_Q_with_SAT(*args, max_solutions=max_solutions, **kwargs))




def canonicalize(Q):
    """
    Returns the canonical form of Q by sorting its columns lexicographically.
    This canonical form is invariant under column permutation.
    
    Parameters:
        Q (np.ndarray): A binary matrix of shape (J, K).
        
    Returns:
        np.ndarray: The canonical form of Q.
    """
    # Convert each column into a tuple, sort them, and rebuild the matrix.
    cols = [tuple(col) for col in Q.T]
    cols_sorted = sorted(cols)
    return np.array(cols_sorted).T

## Randomly generate J times K binary matrix.
def random_generate_Q(J, K):
    # Initialize an empty set to store unique sequences
    sequences = set()

    # Loop until J unique sequences are found
    while len(sequences) < J:
        # Generate a random binary sequence of length K
        seq = tuple(np.random.choice([0, 1], size=K))
        
        # If the sequence is not all zeros, add it to the set
        if any(seq):
            sequences.add(seq)
    
    # Convert the selected sequences into a NumPy array
    Q = np.array(list(sequences))

    # Sort rows of Q
    Q = Q[np.lexsort(Q.T[::-1])]

    return Q


def generate_s_g(J: int, 
                 low: float = 0.05, high: float = 0.35, 
                 rng: np.random.Generator | None = None) -> tuple[np.ndarray, np.ndarray]:
    """
    Generate slip (s) and guess (g) parameters for J items such that 1-s > g (i.e., s+g < 1).
    
    Parameters
    ----------
    J : int
        Number of items.
    low, high : float
        Range to sample s and g before enforcing the constraint.
    rng : np.random.Generator, optional
        Random generator for reproducibility.
    
    Returns
    -------
    s : np.ndarray, shape (J,)
    g : np.ndarray, shape (J,)
    """
    if rng is None:
        rng = np.random.default_rng()

    s = np.zeros(J)
    g = np.zeros(J)

    for j in range(J):
        while True:
            sj = rng.uniform(low, high)
            gj = rng.uniform(low, high)
            if sj + gj < 1:   # satisfies 1 - s > g
                s[j] = sj
                g[j] = gj
                break
    return s, g



def generate_latent_A(N: int, K: int, p: float = 0.5, rng=None) -> np.ndarray:
    """
    Generate latent skills A ∈ {0,1}^{N×K}.
    
    Parameters
    ----------
    N : int
        Number of subjects.
    K : int
        Number of skills.
    p : float
        Probability of mastering each skill independently.
    rng : np.random.Generator, optional
    
    Returns
    -------
    A : np.ndarray, shape (N,K), dtype=uint8
    """
    if rng is None:
        rng = np.random.default_rng()
    return rng.binomial(1, p, size=(N, K)).astype(np.uint8)


def compute_Xi(A: np.ndarray, Q: np.ndarray) -> np.ndarray:
    """
    Compute ideal responses Xi ∈ {0,1}^{N×J}.
    
    Parameters
    ----------
    A : np.ndarray, shape (N,K)
        Latent skill mastery.
    Q : np.ndarray, shape (J,K)
        Q-matrix.
    
    Returns
    -------
    Xi : np.ndarray, shape (N,J)
    """
    # For each item j, take min over required skills
    # Equivalent to (A[:,None,:] ** Q[None,:,:]).prod(axis=2)
    N, K = A.shape
    J, K_ = Q.shape
    assert K == K_
    # dot product checks if all required skills are present
    return ((A @ Q.T) == Q.sum(axis=1)).astype(np.uint8)


def generate_R(Xi: np.ndarray, s: np.ndarray, g: np.ndarray, rng=None) -> np.ndarray:
    """
    Generate observed responses R ∈ {0,1}^{N×J} under DINA with slip s and guess g.
    
    Parameters
    ----------
    Xi : np.ndarray, shape (N,J)
        Ideal responses.
    s : np.ndarray, shape (J,)
        Slip parameters.
    g : np.ndarray, shape (J,)
        Guess parameters.
    rng : np.random.Generator, optional
    
    Returns
    -------
    R : np.ndarray, shape (N,J)
    """
    if rng is None:
        rng = np.random.default_rng()
    N, J = Xi.shape
    # Prob of correct response
    P = Xi * (1 - s) + (1 - Xi) * g   # broadcasting
    return rng.binomial(1, P).astype(np.uint8)


