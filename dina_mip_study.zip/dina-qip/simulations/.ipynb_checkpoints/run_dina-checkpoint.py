# scripts/run_param_sim.py
import argparse, os, time, json, glob
import numpy as np
import pandas as pd

from dina.config import EMConfig, QMipConfig
from dina.em import DINAEM
from simulatedata import simulate_dina
from metrics import q_entry_accuracy, q_exact, q_hamming, q_row_recovery, sg_rmse
from q_candidates import CANDIDATES

import os, time, random, shutil, csv, fcntl
from typing import Dict, Any, Optional, List

def _acquire_lockdir(lockdir: str, timeout_sec: float = 300.0, poll_sec: float = 0.05) -> None:
    t0 = time.time()
    while True:
        try:
            os.mkdir(lockdir)  # atomic on shared FS
            return
        except FileExistsError:
            if time.time() - t0 > timeout_sec:
                raise TimeoutError(f"Timeout waiting for lock: {lockdir}")
            time.sleep(poll_sec + random.random() * poll_sec)

def _release_lockdir(lockdir: str) -> None:
    shutil.rmtree(lockdir, ignore_errors=True)

def _read_csv_header(csv_path: str) -> Optional[List[str]]:
    if not os.path.exists(csv_path) or os.path.getsize(csv_path) == 0:
        return None
    with open(csv_path, "r", newline="") as f:
        reader = csv.reader(f)
        header = next(reader, None)
    return header

def append_row_locked(
    csv_path: str,
    row: Dict[str, Any],
    *,
    lock_timeout_sec: float = 300.0,
) -> None:
    os.makedirs(os.path.dirname(csv_path), exist_ok=True)
    lockdir = csv_path + ".lockdir"

    _acquire_lockdir(lockdir, timeout_sec=lock_timeout_sec)
    try:
        header = _read_csv_header(csv_path)

        # If file is new/empty, define schema from this row (preserves insertion order).
        if header is None:
            fieldnames = list(row.keys())
            write_header = True
        else:
            fieldnames = header
            write_header = False

            # Enforce schema consistency: no extra keys later.
            extra = [k for k in row.keys() if k not in fieldnames]
            if extra:
                raise ValueError(
                    f"Row has keys not in existing CSV header: {extra}\n"
                    f"CSV: {csv_path}\n"
                    f"Header: {fieldnames}"
                )

        # Fill missing keys with empty string to keep csv.DictWriter happy.
        row_aligned = {k: row.get(k, "") for k in fieldnames}

        with open(csv_path, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if write_header:
                writer.writeheader()
            writer.writerow(row_aligned)
            f.flush()
            os.fsync(f.fileno())
    finally:
        _release_lockdir(lockdir)


    

def list_candidates() -> list[tuple[int, tuple[int, int]]]:
    # [(id, shape), ...]
    return [(k, v.shape) for k, v in CANDIDATES.items()]

def resolve_candidate(q_id: int) -> tuple[int, np.ndarray]:
    """
    Return (q_id, Q) given an integer id like 1, 2, 10.
    """
    try:
        return q_id, CANDIDATES[q_id]
    except KeyError:
        available = list(CANDIDATES.keys())
        raise KeyError(f"No Q{q_id}. Available: {available}")

        
def _vec_like(val, J: int) -> np.ndarray:
    """Return a J-length vector; broadcast scalars."""
    if np.isscalar(val):
        return np.full(J, float(val), dtype=float)
    arr = np.asarray(val, dtype=float)
    if arr.shape == (J,):
        return arr
    if arr.size == 1:
        return np.full(J, float(arr.item()), dtype=float)
    raise ValueError(f"Cannot broadcast {arr.shape} to length {J}.")





def main():
    ap = argparse.ArgumentParser(
        description="DINA simulation & recovery (ONE replication; appends to shared CSV)"
    )

    ap.add_argument("--Q", type=int, default=1, help="Candidate Q id (e.g., 1, 2, 10).")
    ap.add_argument("--list", action="store_true", help="List available candidate Q's and exit.")

    ap.add_argument(
        "--rho",
        type=float,
        default=0.0,
        help="Equicorrelation rho for latent theta in Chiu-Douglas-Li attribute simulation.",
    )
    ap.add_argument(
        "--pi_type",
        type=int,
        default=0,
        help=(
            "Mastery marginal type for attribute simulation. "
            "0 = default (e.g., threshold=0 -> P(alpha_k=1)=0.5). "
            "1 = P(alpha_k=1)=k/(1+K)."
        ),
    )

    ap.add_argument("--N", type=int, required=True)
    ap.add_argument("--multistart", type=int, default=10)
    ap.add_argument("--lexi", type=int, default=1, help="1=enable lexi constraints in algorithm")
    ap.add_argument("--Q_init_true", type=int, default=0, help="1=use true Q as init; 0=algorithm init")
    ap.add_argument("--seed_data", type=int, default=0, help="seed for THIS replicate’s data")
    ap.add_argument("--out_root", type=str, required=True, help="root directory to contain the shared CSV")
    ap.add_argument("--s_true", type=float, default=0.2)
    ap.add_argument("--g_true", type=float, default=0.2)
    args = ap.parse_args()

    
    if args.list:
        print("Available candidates:")
        for q_id, shape in list_candidates():
            print(f"[{q_id}] Q{q_id}   shape={shape}")
        return

    q_id, Q_true = resolve_candidate(args.Q)
    J, K = Q_true.shape
    print(f"[INFO] Using Q='{q_id}' with shape J={J}, K={K}")


    # s,g vectors
    s_true = _vec_like(args.s_true, J)
    g_true = _vec_like(args.g_true, J)

    # example bounds (unchanged logic; uses inferred J,K)
    col_lb = [3] * K if K >= 3 else [1] * K
    col_up = None
    row_lb = [1] * J
    row_up = None

    # algorithm configs
    em_cfg = EMConfig(max_iter=200, tol=1e-6, verbose=True, multistart=args.multistart)
    q_cfg = QMipConfig(
        include_identity=True,
        identity_allowed_cols=None,
        include_distinctness=True,
        distinctness_use_indicators=False,
        col_lb=col_lb, col_up=col_up,
        row_lb=row_lb, row_up=row_up,
        lexi=bool(args.lexi), lexi_ascending=False, lexi_strict=bool(args.lexi),
        time_limit=None, mip_gap=0.0, log_to_console=False, clip_eps=1e-12,
    )
    # q_cfg = QMipConfig(
    #     include_identity=False,
    #     identity_allowed_cols=None,
    #     include_distinctness=False,
    #     distinctness_use_indicators=False,
    #     col_lb=None, col_up=None,
    #     row_lb=None, row_up=None,
    #     lexi=bool(args.lexi), lexi_ascending=False, lexi_strict=bool(args.lexi),
    #     time_limit=None, mip_gap=0.0, log_to_console=False, clip_eps=1e-12,
    # )
    Q_init = (Q_true.copy() if args.Q_init_true else None)

    # one replication for THIS seed_data
    t0 = time.time()

    rng = np.random.default_rng(args.seed_data)

    R, A, xi = simulate_dina(
        args.N,
        Q_true,
        s_true,
        g_true,
        rho=args.rho,
        rng=rng,
        pi_type=args.pi_type,
    )

    em = DINAEM()
    out = em.fit(R, K=K, em_cfg=em_cfg, q_cfg=q_cfg, Q_init=Q_init)
    dt = time.time() - t0

    # metrics row
    Q_hat, s_hat, g_hat = out["Q"], out["s"], out["g"]
    out["loglik"]
    row = {
        "Q_name": args.Q,
        "seed_data": args.seed_data,
        "rho": args.rho,
        "pi_type": args.pi_type,
        "loglik": out["loglik"],
        "q_exact": q_exact(Q_true, Q_hat),
        "q_acc": q_entry_accuracy(Q_true, Q_hat),
        "q_hamming": q_hamming(Q_true, Q_hat),
        "q_row_acc": q_row_recovery(Q_true, Q_hat),
        **sg_rmse(s_true, g_true, s_hat, g_hat),
        "iters": len(out["history"]) - 1,
        "runtime_sec": dt,
    }


    out_dir = os.path.join(args.out_root,f"Q{args.Q}/N{args.N}/rho{args.rho}/pi_type{args.pi_type}",)
    csv_path = os.path.join(out_dir, f"multistart{args.multistart}_lexi{int(bool(args.lexi))}_QinitTrue{args.Q_init_true}.csv" )
    os.makedirs(out_dir, exist_ok=True)
    # pd.DataFrame([row]).to_csv(csv_path, index=False)
    append_row_locked(csv_path, row)


    print(f"[INFO] appended seed_data={args.seed_data}")
    
if __name__ == "__main__":
    main()
