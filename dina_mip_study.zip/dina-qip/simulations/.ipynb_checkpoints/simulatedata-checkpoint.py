# dina_simulator.py
from __future__ import annotations
import numpy as np
from typing import Optional, Sequence, Tuple

# =============================================================================
# Simulators
# =============================================================================

def simulate_dina(
    N: int,
    Q: np.ndarray,                # (J,K) 0/1
    s: Sequence[float],           # length J, 0<s_j<1
    g: Sequence[float],           # length J, 0<g_j<1
    rho: float,                   # latent normal equicorrelation
    *,
    rng: Optional[np.random.Generator] = None,
    pi_type: int = 0,             # mastery-marginal type
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Simulate observed responses R under DINA.

    A is generated via Chiu-Douglas-Li (2009):
      θ ~ N(0, Σ),  Σ=(1-ρ)I + ρ11'
      α_k = 1{ θ_k >= t_k }.

    pi_type controls the marginal mastery rates:
      - pi_type = 0: t_k = 0 for all k  (so P(alpha_k=1)=0.5).
      - pi_type = 1: pi_k = 1 - k/(K+1), k=1..K; then t_k = Φ^{-1}(1 - pi_k).

    Returns
    -------
    R : (N,J) binary responses
    A : (N,K) binary attributes
    xi: (N,J) ideal responses under DINA
    """
    if rng is None:
        rng = np.random.default_rng()

    Q = np.asarray(Q, dtype=int)
    if Q.ndim != 2:
        raise ValueError("Q must be a 2D array of shape (J,K).")
    if not set(np.unique(Q)).issubset({0, 1}):
        raise ValueError("Q must be binary (0/1).")
    J, K = Q.shape

    s = np.asarray(s, float).reshape(J)
    g = np.asarray(g, float).reshape(J)
    if not (np.all((0 < s) & (s < 1)) and np.all((0 < g) & (g < 1))):
        raise ValueError("All s_j, g_j must lie in (0,1).")

    rho = float(rho)
    if K > 1:
        lo = -1.0 / (K - 1)
        if not (lo <= rho <= 1.0):
            raise ValueError(f"rho must lie in [{lo}, 1] for K={K}. Got rho={rho}.")

    # Build equicorrelation covariance and sample θ
    Sigma = (1.0 - rho) * np.eye(K) + rho * np.ones((K, K))
    L = np.linalg.cholesky(Sigma)
    theta = rng.standard_normal((N, K)) @ L.T

    # Thresholds (control marginals)
    if pi_type == 0:
        t = np.zeros(K)
    elif pi_type == 1:
        # pi_k = 1 - k/(K+1), for k=1..K
        pi = 1.0 - np.arange(1, K + 1, dtype=float) / (K + 1.0)
        # t_k = Φ^{-1}(1 - pi_k)
        from scipy.stats import norm
        t = norm.ppf(1.0 - pi)
    else:
        raise ValueError(f"Unknown pi_type={pi_type}. Supported: 0, 1.")

    A = (theta >= t[None, :]).astype(int)

    # Ideal ξ under DINA: 1 iff a_n covers all required skills in item j
    xi = (A[:, None, :] >= Q[None, :, :]).all(axis=2).astype(int)

    # Noisy observed R
    U = rng.random((N, J))
    p_correct = xi * (1 - s) + (1 - xi) * g
    R = (U < p_correct).astype(int)

    return R, A, xi
