import argparse, os, glob
import pandas as pd

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="results")
    args = ap.parse_args()
    rows = []
    for csv in glob.glob(os.path.join(args.root, "**", "replicates.csv"), recursive=True):
        df = pd.read_csv(csv)
        row = df.describe().loc[["mean","std"]].to_dict()
        rows.append({"path": csv, "n": len(df), "summary": row})
    print(f"Found {len(rows)} result tables.")
    for r in rows:
        print(r["path"], "n=", r["n"])

if __name__ == "__main__":
    main()
